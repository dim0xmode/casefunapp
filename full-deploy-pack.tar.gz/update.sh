#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${1:-/root/casefun}"
COMPOSE_FILE="${APP_DIR}/docker-compose.prod.yml"

cd "$APP_DIR"

git pull
docker compose -f "$COMPOSE_FILE" up -d --build
docker compose -f "$COMPOSE_FILE" exec backend npx prisma migrate deploy

echo "OK: updated and restarted"
