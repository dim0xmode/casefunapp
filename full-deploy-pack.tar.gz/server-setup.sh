#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${1:-/root/casefun}"

if [ ! -d "$APP_DIR" ]; then
  echo "ERROR: app dir not found: $APP_DIR"
  exit 1
fi

cd "$APP_DIR"

gen_secret() {
  local bytes="$1"
  if command -v openssl >/dev/null 2>&1; then
    openssl rand -hex "$bytes"
  else
    python3 - <<PY
import secrets
print(secrets.token_hex($bytes))
PY
  fi
}

DB_PASS="$(gen_secret 16)"
JWT_SECRET="$(gen_secret 32)"

cat <<'EOF' > backend/.env
NODE_ENV=production
PORT=3001
FRONTEND_URL=https://casefun.net

# Database
DATABASE_URL="postgresql://casefun:__DB_PASS__@db:5432/casefun?schema=public"

# Auth / Sessions
JWT_SECRET=__JWT_SECRET__
SESSION_TTL_DAYS=30
NONCE_TTL_MINUTES=15
BOOTSTRAP_ADMIN_WALLET=0xc459241D1AC02250dE56b8B7165ebEDF59236524
EOF

sed -i.bak "s/__DB_PASS__/${DB_PASS}/g; s/__JWT_SECRET__/${JWT_SECRET}/g" backend/.env
rm -f backend/.env.bak

cat <<'EOF' > frontend/.env.production
VITE_API_URL=https://casefun.net/api
EOF

cat <<'EOF' > backend/Dockerfile
FROM node:20-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --omit=dev

COPY . .

RUN npm run build
RUN npx prisma generate

ENV NODE_ENV=production
EXPOSE 3001

CMD ["node", "dist/index.js"]
EOF

cat <<'EOF' > frontend/Dockerfile
FROM node:20-alpine as build

WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
EXPOSE 80
EOF

cat <<'EOF' > Caddyfile
casefun.net {
  encode gzip zstd
  reverse_proxy /api/* backend:3001
  reverse_proxy frontend:80
}
EOF

cat <<'EOF' > docker-compose.prod.yml
services:
  db:
    image: postgres:16
    environment:
      POSTGRES_USER: casefun
      POSTGRES_PASSWORD: __DB_PASS__
      POSTGRES_DB: casefun
    volumes:
      - db_data:/var/lib/postgresql/data
    restart: unless-stopped

  backend:
    build: ./backend
    env_file:
      - ./backend/.env
    depends_on:
      - db
    restart: unless-stopped

  frontend:
    build: ./frontend
    restart: unless-stopped

  caddy:
    image: caddy:2
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./Caddyfile:/etc/caddy/Caddyfile
      - caddy_data:/data
      - caddy_config:/config
    depends_on:
      - backend
      - frontend
    restart: unless-stopped

volumes:
  db_data:
  caddy_data:
  caddy_config:
EOF

sed -i.bak "s/__DB_PASS__/${DB_PASS}/g" docker-compose.prod.yml
rm -f docker-compose.prod.yml.bak

echo "OK: files written in $APP_DIR"
echo "DB_PASSWORD=${DB_PASS}"
echo "JWT_SECRET=${JWT_SECRET}"
