-- Add avatar URL to users
ALTER TABLE "users" ADD COLUMN "avatarUrl" TEXT;
